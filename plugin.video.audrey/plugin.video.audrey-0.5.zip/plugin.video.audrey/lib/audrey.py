import json, ast, re, os, json, urllib
import xbmcaddon, xbmc
import util
import urlresolver

supports=["youtube", "openload", "movpod", "zstream", "yourupload", "xvidstage", "faststream", "weshare", "watchvideo", "watchonline", "watchers", "vshare", "vodlock", "vimeo", "vidzi", "vidwatch", "vidup", "vidtodo", "vidstreaming", "vidoza", "vid.me", "vidmad", "tamildrive", "vidlox", "vidics", "vidhos", "byzoo", "playpanda", "videozoo", "videowing", "easyvideo", "play44", "playbb", "video44", "videowood", "bitvid", "videoweed", "videoraj", "videohut", "videoget", "videocloud", "thevideobee", "vidabc", "veehd", "ustream", "usersfiles", "userscloud", "tusfiles", "tubitv", "trollvid", "mp4edge",  "toltsd-fel", "thevideo", "tvad", "teramixer", "streamplay", "stream.moe", "streamin.to", "streame", "streamango", "streamcherry", "stagevu", "spruto", "speedvideo", "speedwatch", "speedvid", "speedplay", "rutube", "rapidvideo", "raptu", "putload", "shitmovie", "powvideo", "playwire", "playhd", "playedto", "play44", "ok.ru", "ocloud", "nowvideo", "novamov", "auroravid", "nosvideo", "noslocker", "myvi", "mystream", "mycloud", "mcloud", "mp4upload", "mp4stream", "movshare", "wholecloud", "vidgg", "mersalaayitten", "mehlizmovies", "megamp4", "mail.ru", "lolzor", "mycollection", "adhqmedia", "gagomatic", "funblr", "favour", "vidbaba", "likeafool", "kingvid", "jetload", "hdvid", "h265.se", "grifthost", "gorillavid", "googlevideo.com", "googleusercontent.com", "get.google.com", "plus.google.com", "googledrive.com", "drive.google.com", "docs.google.com", "youtube.googleapis.com", "goodvideohost", "goflicker", "getvi", "gamovideo", "flashx", "filez.tv", "fileweed", "fastplay.sx", "estream.to", "ecostream.tv", "earnvideos", "downace.com", "cloudtime", "divxstage", "dailymotion", "daclips", "cloudy.ec", "cloudy.eu", "cloudy.sx", "cloudy.ch", "cloudy.com", "clipwatching.com", "castamp", "blazefile", "bitvid.sx", "beststream", "apnasave", "anistream", "anime-portal", "9xplay"]

ADDON_ID='plugin.video.audrey'
audrey=xbmcaddon.Addon(id=ADDON_ID)                 

def feedme(feed="", type=""):
    colour = ["black", "white", "gray", "blue", "teal", "fuchsia", "indigo", "turquoise", "cyan", "greenyellow", "lime", "green", "olive", "gold", "yello", "lavender", "pink", "magenta", "purple", "maroon", "chocolate", "orange", "red", "brown"]
    parameters=util.parseParameters()
    try:
        mode=int(parameters["mode"])
    except:
        mode=None

    if mode==1:
        # first level within a site, show Latest, Search and any Tags within the specified site
        menu=[]
        
        extras=ast.literal_eval(parameters['extras'])
        
        bits=util.getFile(feed, type)
        site=bits['sites'][extras['site']]
        
        if "search" not in site and "tags" not in site and len(site['items'])==1:
            mode=2
            for item in site['items']:
                parameters['url']=site['items'][item][0]['site_url']
                break
                
        else:
            for item in sorted(site['items'].iterkeys()):
                extras['level']=item
                menu.append({
                    "title": item,
                    "url": urllib.quote_plus(site['items'][item][0]['site_url']),
                    "mode": "2", 
                    "poster":parameters['poster'],
                    "icon":parameters['poster'], 
                    "fanart":parameters['fanart'],
                    "type":"", 
                    "plot":"",
                    "isFolder":True,
                    "extras":str(extras)
                })
            
            try:
                counter=0
                for tag in site['tags']:
                    extras['tag']=counter
                    menu.append({
                        "title": tag['name'],
                        "url": tag['url'],
                        "mode": "4", 
                        "poster":parameters['poster'],
                        "icon":parameters['poster'], 
                        "fanart":parameters['fanart'],
                        "type":"", 
                        "plot":"",
                        "isFolder":True,
                        "extras":str(extras)
                    })
                    counter=counter+1
            except:
                pass
            if "search_url" in site:
                menu.append({
                    "title": "Search",
                    "url": "",
                    "mode": "3", 
                    "poster":parameters['poster'],
                    "icon":parameters['poster'], 
                    "fanart":parameters['fanart'],
                    "type":"", 
                    "plot":"",
                    "isFolder":True,
                    "extras":str(extras)
                })
            util.addMenuItems(menu)
    if mode==2:
        # load the first level of relevant video information
        menu = []
        extras=ast.literal_eval(parameters['extras'])
        
        bits=util.getFile(feed, type)
        site=bits['sites'][extras['site']]
        
        if 'pos' in extras:
            pos=extras['pos']
        else:
            pos=0
            
        if 'level' in extras:
            level=extras['level']
        else:
            for item in site['items']:
                level=item
                break
            
        if len(site['items'][level])>pos+1:
            # another level is needed
            extras['pos']=pos+1
            newMode="2"
            isFolder=True
        else:
            # on a level where next move is to check for sources
            newMode="111" # find source
            isFolder=False
            
        #util.alert(newMode)
        
        page=util.get(parameters['url'])
        next=page
        
        try:
            if site['items'][level][pos]['global']!="":
                regex = util.prepare(site['items'][level][pos]['global'])
                matches = re.findall(regex, page)
                if matches:
                    page=matches[0]
        except:
            pass
        
        regex = util.prepare(site['items'][level][pos]['pattern'])
        matches = re.findall(regex, page)
        if matches:
            counter=0
            for match in matches:
                try:
                    title=util.replaceParts(site['items'][level][pos]['name'], matches[counter]).replace('\n', '').replace('\t', '').lstrip().encode('utf-8')
                except:
                    title=""
                try:
                    url=util.replaceParts(site['items'][level][pos]['url'], matches[counter]).encode('utf-8')
                except:
                    url=""
                try:
                    poster=util.replaceParts(site['items'][level][pos]['poster'], matches[counter]).encode('utf-8')
                except:
                    poster=""
                try:
                    fanart=util.replaceParts(site['items'][level][pos]['fanart'], matches[counter]).encode('utf-8')
                except:
                    fanart=""
                try:
                    plot=util.replaceParts(site['items'][level][pos]['plot'], matches[counter]).encode('utf-8')
                except:
                    plot=""
                    
                if isFolder:
                    menu.append({
                        "title": title,
                        "url": url,
                        "mode": newMode, 
                        "poster":poster,
                        "icon":poster, 
                        "fanart":fanart,
                        "type":"", 
                        "plot":plot,
                        "isFolder":isFolder,
                        "extras":str(extras)
                    })
                else:
                    menu.append({
                        "title": title,
                        "url": url,
                        "mode": newMode, 
                        "poster":poster,
                        "icon":poster, 
                        "fanart":fanart,
                        "type":"", 
                        "plot":plot,
                        "isFolder":isFolder,
                        "isPlayable":"True",
                        "extras":str(extras)
                    })
                counter=counter+1
        try:
            regex = util.prepare(site['items'][level][pos]['next_pattern'])
            matches = re.findall(regex, next)
            if matches:
                nextlink=util.replaceParts(site['items'][level][pos]['next_url'], matches)
                util.logError(nextlink)
                menu.append({
                    "title": "Next Page >",
                    "url": nextlink,
                    "mode": "2", 
                    "poster":"",
                    "icon":"", 
                    "fanart":"",
                    "type":"", 
                    "plot":plot,
                    "isFolder":True,
                    "extras":str(extras)
                })
        except:
            pass
        util.addMenuItems(menu)
    elif mode==3:
        # display the Search dialog and build search results
        menu = []
        extras=ast.literal_eval(parameters['extras'])
        term=util.searchDialog()
        
        bits=util.getFile(feed, type)
        site=bits['sites'][extras['site']]
        
        pos=0
        if len(site['item'])>pos+1:
            # another level is needed
            extras['pos']=pos+1
            newMode="2"
            isFolder=True
            isPlayable=True
        else:
            # on a level where next move is to check for sources
            newMode="111" # find source
            isFolder=False
            isPlayable=True
        
        page=util.get(site['search_url'].replace("{%}", term))
        next=page
        
        try:
            if site['item']['global']!="":
                regex = util.prepare(site['item']['global'])
                matches = re.findall(regex, page)
                if matches:
                    page=matches[0]
        except:
            pass
        
        regex = util.prepare(site['item'][0]['pattern'])
        matches = re.findall(regex, page)
        if matches:
            counter=0
            for match in matches:
                try:
                    title=util.replaceParts(site['item'][0]['name'], matches[counter]).encode('utf-8')
                except:
                    title=""
                try:
                    url=util.replaceParts(site['item'][0]['url'], matches[counter]).encode('utf-8')
                except:
                    url=""
                try:
                    poster=util.replaceParts(site['item'][0]['poster'], matches[counter]).encode('utf-8')
                except:
                    poster=""
                try:
                    fanart=util.replaceParts(site['item'][0]['fanart'], matches[counter]).encode('utf-8')
                except:
                    fanart=""
                try:
                    plot=util.replaceParts(site['item'][0]['plot'], matches[counter]).encode('utf-8')
                except:
                    plot=""
                menu.append({
                    "title": title,
                    "url": url,
                    "mode": newMode, 
                    "poster":poster,
                    "icon":poster, 
                    "fanart":fanart,
                    "type":"", 
                    "plot":plot,
                    "isFolder":isFolder,
                    "isPlayable":isPlayable,
                    "extras":extras
                })
                counter=counter+1
        try:
            regex = util.prepare(site['item'][0]['next'])
            matches = re.findall(regex, next)
            if matches:
                menu.append({
                    "title": "Next Page >",
                    "url": matches[0],
                    "mode": "2", 
                    "poster":"",
                    "icon":"", 
                    "fanart":"",
                    "type":"", 
                    "plot":plot,
                    "isFolder":True,
                    "extras":extras
                })
        except:
            pass
        util.addMenuItems(menu)
    elif mode==4:
        # show relevant Tag video results
        menu = []
        
        extras=ast.literal_eval(parameters['extras'])
        
        bits=util.getFile(feed, type)
        
        site=bits['sites'][extras['site']]['tags'][extras['tag']]
        
        page=util.get(parameters['url'])
        next=page
        
        try:
            if site['item']['global']!="":
                regex = util.prepare(site['item']['global'])
                matches = re.findall(regex, page)
                if matches:
                    page=matches[0]
        except:
            pass
            
        regex = util.prepare(site['item']['pattern'])
        matches = re.findall(regex, page)    
        if matches:
            counter=0
            for match in matches:
                try:
                    title=util.replaceParts(site['item']['name'], matches[counter]).encode('utf-8')
                except:
                    title=""
                try:
                    url=util.replaceParts(site['item']['url'], matches[counter]).encode('utf-8')
                except:
                    url=""
                try:
                    poster=util.replaceParts(site['item']['poster'], matches[counter]).encode('utf-8')
                except:
                    poster=""
                try:
                    fanart=util.replaceParts(site['item']['fanart'], matches[counter]).encode('utf-8')
                except:
                    fanart=""
                try:
                    plot=util.replaceParts(site['item']['plot'], matches[counter]).encode('utf-8')
                except:
                    plot=""
                
                menu.append({
                    "title": title,
                    "url": url,
                    "mode": "2", 
                    "poster":poster,
                    "icon":poster, 
                    "fanart":fanart,
                    "type":"", 
                    "plot":plot,
                    "isFolder":True,
                    "extras":extras
                })
                counter=counter+1
        util.addMenuItems(menu)
    elif mode==5:
        pass
    elif mode==111:
        # find playable sources in url
        extras=ast.literal_eval(parameters['extras'])
        bits=util.getFile(feed, type)
        site=bits['sites'][extras['site']]
        
        page=util.get(parameters['url'])
        
        if "urlresolver" in site and site['urlresolver'].lower()=="false":
            regex="\"(.*?\.mp4)\""
            matches = re.findall(regex, page)
            if matches:
                util.playMedia(parameters['name'], parameters['poster'], matches[0], force=True)
        else:
            # check passed ur
            link=urlresolver.resolve(parameters['url'])
            if link:
                util.playMedia(parameters['name'], parameters['poster'], link, force=True)
            else:
                try:
                    regex="(\/\/.*?\/embed.*?)[\?\"]"
                    matches = re.findall(regex, page)
                    regex = 'https?://(.*?(?:\.googlevideo|(?:plus|drive|get|docs)\.google|google(?:usercontent|drive|apis))\.com)/(.*?(?:videoplayback\?|[\?&]authkey|host/)*.+)'
                    matches = matches + re.findall(regex, page)
                    if matches:
                        matches=[ x for x in matches if any(sup in x for sup in supports) ]
                        if matches:
                            link=urlresolver.resolve("http:"+matches[0])
                            if link:
                                util.playMedia(parameters['name'], parameters['poster'], link, force=True)
                            else:
                                util.notify("No video found")
                        else:
                                util.notify("No video found")
                    else:
                                util.notify("No video found")
                except Exception as e:
                    util.notify("There was an error with the video")
                    util.logError(str(e))
    elif mode==112:
        extras=ast.literal_eval(parameters['extras'])
        bits=util.getFile(feed, type)
        site=bits['sites'][extras['site']]
        
        page=util.get(parameters['url'])
        
        if "urlresolver" in site and site['urlresolver'].lower()=="false":
            regex="\"(.*?\.mp4)\""
            matches = re.findall(regex, page)
            if matches:
                link=matches[0]
        else:
            # check passed ur
            link=urlresolver.resolve(parameters['url'])
            if not link:
                try:
                    regex="(\/\/.*?\/embed.*?)[\?\"]"
                    matches = re.findall(regex, page)
                    regex="\"((?:http:|https:)?\/\/.*?\/watch.*?)[\"]"
                    matches = matches + re.findall(regex, page)
                    regex = 'https?://(.*?(?:\.googlevideo|(?:plus|drive|get|docs)\.google|google(?:usercontent|drive|apis))\.com)/(.*?(?:videoplayback\?|[\?&]authkey|host/)*.+)'
                    matches = matches + re.findall(regex, page)
                    if matches:
                        matches=[ x for x in matches if any(sup in x for sup in supports) ]
                        if matches:
                            link=urlresolver.resolve("http:"+matches[0])
                except Exception as e:
                    util.notify(str(e))
        if link:
            import downloader
            downloader.download(link, os.path.join(xbmcaddon.Addon().getSetting('folder'), parameters['name']+".mp4"))
        else:
            util.notify("No video found")
    else:
        # if we get here list the sites found in the json file
        menu=[]
        bits=util.getFile(feed, type)
        counter=0
        
        try:
            folder=ast.literal_eval(parameters['extras'])
            folder=folder['folder']
            for site in bits['sites']:
                try:
                    if site['folder'].lower()==folder.lower():
                        extras={}
                        extras['site']=counter
                        menu.append({
                            "title": site['name'],
                            "url": site['name'],
                            "mode": "1", 
                            "poster":site['poster'],
                            "icon":site['poster'], 
                            "fanart":site['fanart'],
                            "type":"", 
                            "plot":"",
                            "isFolder":True,
                            "extras":extras
                        })
                    counter=counter+1
                except:
                    # site not in a folder
                    pass
        except:
            if "folders" in bits:
                for site in bits['folders']:
                    extras={}
                    extras['site']=counter
                    menu.append({
                        "title": "[COLOR "+colour[int(audrey.getSetting('colour'))]+"]"+site['name']+"[/COLOR]",
                        "url": site['name'],
                        "mode": "0", 
                        "poster":site['poster'],
                        "icon":site['poster'], 
                        "fanart":site['fanart'],
                        "type":"", 
                        "plot":"",
                        "isFolder":True,
                        "extras":{"folder":site['name']}
                    })
            for site in bits['sites']:
                if "folder" not in site:
                    extras={}
                    extras['site']=counter
                    menu.append({
                        "title": site['name'],
                        "url": site['name'],
                        "mode": "1", 
                        "poster":site['poster'],
                        "icon":site['poster'], 
                        "fanart":site['fanart'],
                        "type":"", 
                        "plot":"",
                        "isFolder":True,
                        "extras":extras
                    })
                counter=counter+1
        util.addMenuItems(menu)