import audrey

audrey.feedme("https://www.jasonbase.com/things/MjA5.json", "url")
