import urllib2, re, urllib, base64, difflib, time, json, base64, HTMLParser, time, sys
import xbmcaddon,xbmcplugin,xbmcgui
import util, sexloading, ivhunter

hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
       'Accept-Encoding': 'none',
       'Accept-Language': 'en-US,en;q=0.8',
       'Connection': 'keep-alive'}
       
ADDON_ID='plugin.video.javstream'

sysarg=str(sys.argv[1]) 
    
def getVids(urls) :
    for url in urls:
        if "sexloading" in url:
            param=sexloading.showVideos(url, hdr)
        elif "ivhunter" in url:
            param=ivhunter.showVideos(url, hdr)
        buildVideoMenu(param)
    xbmcplugin.endOfDirectory(int(sysarg))
   
def buildVideoMenu(param):
    loadNext=[]
    for video in param:
        if video[0]=='next':
            loadNext.append(video[1])
        else:
            u=sys.argv[0]+"?url="+video[5]+"&play="+str(4)+"&name="+urllib.quote_plus(util.makeAscii(video[0]))+"&poster="+video[6]
            liz=xbmcgui.ListItem(util.makeAscii(video[0]), iconImage="DefaultVideo.png", thumbnailImage=video[6])
            liz.setInfo( type="Video", infoLabels={ "Title": util.makeAscii(video[0]),"Plot": video[1]} )
            liz.setProperty("Fanart_Image", video[7])
            liz.setProperty("Landscape_Image", video[7])
            liz.setProperty("Poster_Image", video[6])
            ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    
    if len(loadNext)>0:
        if len(loadNext)==1:
            util.addDir("Next Page >", loadNext[0], 1, "")
        else:
            util.addDir("Next Page >", "<split>".join(loadNext), 4, "")            
        
def buildMainMenu():
    util.addDir("JAV","JAV", 2, "")
    util.addDir("Gravure", "Gravure", 2, "")
    util.addDir("Latest JAV", "http://sexloading.com/", 1, "")
    util.addDir("Latest Gravure", "http://ivhunter.com", 1, "")
    util.addDir("Search","http://sexloading.com/?s=<split>http://ivhunter.com/?s=", 3, "","")
    xbmcplugin.endOfDirectory(int(sysarg))

def buildSubMenu(params):
    if params['url']=='JAV':
        util.addDir("Genres", "http://sexloading.com/faq/", 5, "")
        util.addDir("Censored", "http://sexloading.com/censored/", 1, "")
        util.addDir("Uncensored", "http://sexloading.com/uncensored/", 1, "")
        util.addDir("Most Popular JAV", "http://sexloading.com/", 6, "")
        util.addDir("Latest JAV", "http://sexloading.com/", 1, "")
    elif params['url']=="Gravure":
        util.addDir("Studios", "http://ivhunter.com/note/", 7, "")
        util.addDir("Idols", "http://ivhunter.com/idols-library/", 8, "")
        util.addDir("Most Popular Gravure", "http://ivhunter.com/", 9, "")
        util.addDir("Latest Gravure", "http://ivhunter.com", 1, "")
    xbmcplugin.endOfDirectory(int(sysarg))
        
def search(urls):
    toSend=[]
    term=util.searchBox()
    for url in urls:
        toSend.append(url+term)
    getVids(toSend)
    
def playVideo(params):
    content=util.getURL(params['url'].encode('utf-8'), hdr)
    xbmc.log("load this: "+params['url'].encode('utf-8'), xbmc.LOGERROR)
    if content!=False:
        
        if "https://openload" in content:
            download=util.extract(content, '<iframe src="https://openload', '"')
            openloadurl ='http://openload'+download.encode('utf-8')
            ol=util.getURL(openloadurl, hdr)
            videourl=util.extract(ol, '<source type="video/mp4" src="', '"')  
            
        elif "http://videowood.tv/embed/" in content:
            download=util.extract(content, 'http://videowood.tv/embed/', '"')
            videowoodurl='http://videowood.tv/embed/'+download
            vw=util.getURL(videowoodurl, hdr)
            videourls=util.extractAll(vw, "file: '", "',")
            for vid in videourls:
                if '.mp4' in vid:
                    videourl=vid
                    break
        xbmc.log(videourl, xbmc.LOGERROR)
        
        util.playMedia(params['name'], params['poster'],videourl, "Video")

parameters=util.parseParameters()
try:
    mode=int(parameters["mode"])
except:
    mode=None
    
if mode==1:
    getVids([parameters['url'].encode('utf-8')])
elif mode==2:
    buildSubMenu(parameters)
elif mode==3:
    search(parameters['url'].split('<split>'))
elif mode==4:
    getVids(parameters['url'].split('<split>'))
elif mode==5:
    sexloading.getGenres(parameters['url'], hdr)
elif mode==6:
    buildVideoMenu(sexloading.getPopular(parameters['url'], hdr))
    xbmcplugin.endOfDirectory(int(sysarg))
elif mode==7:
    ivhunter.getStudios(parameters['url'], hdr);
elif mode==8:
    ivhunter.getIdols(parameters['url'], hdr);
elif mode==9:
    buildVideoMenu(ivhunter.getPopular(parameters['url'], hdr))
    xbmcplugin.endOfDirectory(int(sysarg))
elif 'play' in parameters:
    playVideo(parameters)
else:
    buildMainMenu()
