import audrey, xbmcaddon
audrey.feedme("https://jasonbase.com/things/mXZy.json", "url")