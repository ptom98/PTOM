import urllib
import menu, util
import xbmcplugin, xbmcaddon

sysarg=str(sys.argv[1])
ADDON_ID='plugin.video.sledgehammer'
addon = xbmcaddon.Addon(id=ADDON_ID)

# test accessing the addon settings
# util.notify(ADDON_ID, xbmcplugin.getSetting(int(sysarg), "language"))

parameters=util.parseParameters()
try:
    mode=int(parameters["mode"])
except:
    mode=None
  
if mode==1:
    # display the TVShow specific sub menu
    util.addMenuItems(menu.tvMenu)
elif mode==2:
    # display the Movie specific sub menu
    util.addMenuItems(menu.movieMenu)
elif mode==3:
	# display the Search specific sub menu
	util.addMenuItems(menu.searchMenu)    
elif mode==31:
    try:
        util.findVideos(parameters['search'], 'tv', parameters['page'])
    except:
        # lets start searching for tv shows
        search=util.searchDialog()
        if (search):
            # something has been typed, lets search for it
            util.findVideos(search, 'tv')
elif mode==32:
    try:
        util.findVideos(parameters['search'], 'movie', parameters['page'])
    except:
        # lets start searching for movies
        search=util.searchDialog()
        if (search):
            # something has been typed, lets search for it
            util.findVideos(search, 'movie')
elif mode==33:
    try:
        util.findPerson(parameters['search'], 'person', parameters['page'])
    except:
		# lets start searching for actors
		search=util.searchDialog()
		if (search):
			# something has been typed, lets search for it
			util.findPerson(search, 'person')
elif mode==201:
    util.findVideos("", 'popular_movies')
elif mode==202:
    util.findVideos("", 'highest_movies')
elif mode==1000:
    util.scrapeWF(parameters, 'movie')
elif mode==9999:
    util.getMediaURL(parameters)
else:
    # if we get here then there's nothing to do except display the main menu
    util.addMenuItems(menu.movieMenu)