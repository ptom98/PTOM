import urllib, os
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

ADDON_ID='plugin.video.sledgehammer'
addon=xbmcaddon.Addon(id=ADDON_ID)
home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

# the main menu structure
mainMenu=[
	{
        "title":"TV Shows", 
        "url":"none", 
        "mode":1, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
	{
        "title":"Movies", 
        "url":"none", 
        "mode":2, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
    {
        "title":"Search", 
        "url":"none", 
        "mode":3, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
]

# the search menu structure
searchMenu=[
    {
        "title":"Search TV Shows", 
        "url":"none", 
        "mode":31, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
	{
        "title":"Search Movies", 
        "url":"none", 
        "mode":32, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
	{
        "title":"Search by Actor", 
        "url":"none", 
        "mode":33, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
]

# the tv show menu structure
tvMenu=[
    {
        "title":"Search TV Shows", 
        "url":"none", 
        "mode":31, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
]

movieMenu=[
    {
        "title":"Popular Movies", 
        "url":"none", 
        "mode":201, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
    {
        "title":"Search Movies", 
        "url":"none", 
        "mode":32, 
        "poster":"none",
        "icon":"none", 
        "fanart":"none",
        "type":"", 
        "plot":""
    },
]