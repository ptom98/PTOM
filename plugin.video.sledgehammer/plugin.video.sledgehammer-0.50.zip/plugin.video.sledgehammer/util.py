#-*- coding: utf-8 -*-

import sys, urllib, urllib2, re, cookielib, os.path, json, base64, datetime, time
from bs4 import BeautifulSoup
from datetime import datetime
import xml.etree.ElementTree as ET
import xbmc, xbmcplugin, xbmcgui, xbmcaddon
import urlresolver

API_KEY = 'b7152dc7f98b9684aee951a59dc74dc7'

sysarg=str(sys.argv[1])
ADDON_ID='plugin.video.sledgehammer'
addon = xbmcaddon.Addon(id=ADDON_ID)

hdr = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.64 Safari/537.11',
       'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
       'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.3',
       'Accept-Encoding': 'none',
       'Accept-Language': 'en-US,en;q=0.8',
       'Connection': 'keep-alive'}
       
profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir).decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')       

urlopen = urllib2.urlopen
cj = cookielib.LWPCookieJar()
Request = urllib2.Request

home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

def parseParameters(inputString=sys.argv[2]):
    """Parses a parameter string starting at the first ? found in inputString
    
    Argument:
    inputString: the string to be parsed, sys.argv[2] by default
    
    Returns a dictionary with parameter names as keys and parameter values as values
    """
    parameters = {}
    p1 = inputString.find('?')
    if p1 >= 0:
        splitParameters = inputString[p1 + 1:].split('&')
        for nameValuePair in splitParameters:
            if (len(nameValuePair) > 0):
                pair = nameValuePair.split('=')
                key = pair[0]
                value = urllib.unquote(urllib.unquote_plus(pair[1])).decode('utf-8')
                parameters[key] = value
    return parameters

def getHTML(url, header):
    try:
        req = urllib2.Request(url, headers=header)
        response = urllib2.urlopen(req)
        if response and response.getcode() == 200:
            if response.info().get('Content-Encoding') == 'gzip':
                buf = StringIO.StringIO( response.read())
                gzip_f = gzip.GzipFile(fileobj=buf)
                content = gzip_f.read()
            else:
                content = response.read()
            content = content.decode('utf-8', 'ignore')
            return content
    except:
        xbmc.log('Error Loading URL : '+url.encode("utf-8"), xbmc.LOGERROR)
        try:
            xbmc.log("Error Code: "+str(response.getcode())+' Content: '+response.read(), xbmc.LOGERROR)
        except:
            pass
    
    return False
    
def addMenuItems(details, show=True):
    for detail in details:
        u=sys.argv[0]+"?url="+detail['url']+"&mode="+str(detail['mode'])+"&name="+urllib.quote_plus(detail['title'])+"&icon="+detail['icon']
        liz=xbmcgui.ListItem(detail['title'], iconImage=detail['icon'])
        liz.setInfo(type=detail['type'], infoLabels={ "Title": detail['title'],"Plot": detail['plot']} )
        
		
			
        try:
            u=u+"&extras="+detail["extras"]
        except:
            pass
			
        try:
            u=u+"&extras2="+detail["extras2"]
        except:
            pass
			
        try:
            liz.setProperty("Fanart_Image", detail['fanart'])
            u=u+"&fanart="+detail['fanart']
        except:
            pass
			
        try:
            liz.setProperty("Landscape_Image", detail['landscape'])
            u=u+"&landscape="+detail['landscape']
        except:
            pass
			
        try:
            liz.setProperty("Poster_Image", detail['poster'])
            u=u+"&poster="+detail['poster']
        except:
            pass
			
        try:
            u=u+"&page="+str(detail["page"])
        except:
            pass
			
        try:
            u=u+"&search="+str(detail['search'])
        except:
            pass
            
        try:
            u=u+"&year="+str(detail['year'])
        except:
            pass
        
        try:
            u=u+"&realname="+str(detail['realname'])
        except:
            pass
			
		
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
    if show:
        xbmcplugin.endOfDirectory(int(sysarg))

def alert(alertText):
    dialog = xbmcgui.Dialog()
    ret = dialog.ok("JAVStream", alertText.title())
        
def notify(addonId, message, reportError=False, timeShown=2000):
    """Displays a notification to the user
    
    Parameters:
    addonId: the current addon id
    message: the message to be shown
    timeShown: the length of time for which the notification will be shown, in milliseconds, 5 seconds by default
    """
    addon = xbmcaddon.Addon(addonId)
    xbmc.executebuiltin('Notification(%s, %s, %d, %s)' % (addon.getAddonInfo('name'), message, timeShown, addon.getAddonInfo('icon')))
    if reportError:
        logError(message)

def logError(error):
    try:
        xbmc.log("JAVStream Error - "+str(error.encode("utf-8")), xbmc.LOGERROR)
    except:
        xbmc.log("JAVStream Error - "+str(error), xbmc.LOGERROR)
    
def searchDialog(searchText="Please enter search text") :    
    keyb=xbmc.Keyboard('', searchText)
    keyb.doModal()
    searchText=''
    
    if (keyb.isConfirmed()) :
        searchText = keyb.getText()
    if searchText!='':
        return searchText

def progressStart(title, status):
    pDialog = xbmcgui.DialogProgress()
    ret = pDialog.create(title, status)
    progressUpdate(pDialog, 1, status)
    return pDialog

def progressStop(pDialog):
    pDialog.close
    
def progressCancelled(pDialog):
    if pDialog.iscanceled():
        return True
    return False

def progressUpdate(pDialog, progress, status):
    pDialog.update(progress, status)

def customDialog(imgW, imgH, img):
    cDialog=xbmcgui.WindowDialog()
    cWindow=xbmcgui.Window()
    logError(cWindow.getResolution())
    cDialog.addControl(xbmcgui.ControlImage(x=cWindow.getWidth()/2, y=30, width=imgW, height=imgH, filename=img))
    cDialog.show()
    return cDialog

def customDialogClose(cDialog):
    cDialog.close()

def tmdb_find(query, type, page=1):
    if type=="popular_movies":
        j=getHTML('http://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key='+API_KEY+'&page='+str(page), hdr)
    else:
        j=getHTML('http://api.themoviedb.org/3/search/'+type+'?query='+urllib.quote_plus(str(query))+'&api_key='+API_KEY+'&page='+str(page), hdr)
        
    return json.loads(j)

def findVideos(s, type, page=1):
    search=str(s)
    response=tmdb_find(search, type, page)
    if response!=False:
        items=[]
        nowDate=datetime.now().strftime('%Y-%m-%d')
        for item in response['results']:
            releaseDate=item['release_date'].replace("-", "")
            
            if releaseDate<nowDate:
                if type=='tv':
                    title=str(item['name'].encode("utf-8"))
                    mode=1000
                    next_mode=31
                elif type=='movie':
                    title=str(item['title'].encode("utf-8"))
                    mode=1000
                    next_mode=32
                elif type=='popular_movies':
                    title=str(item['title'].encode("utf-8"))
                    mode=1000
                    next_mode=201
                    search='none'
                
                items.append({
                    "title": title,
                    "url": str(item['id']), 
                    "mode":mode, 
                    "poster":'https://image.tmdb.org/t/p/w300/'+str(item['poster_path']),
                    "icon":'https://image.tmdb.org/t/p/w300/'+str(item['poster_path']), 
                    "fanart":'https://image.tmdb.org/t/p/w1000/'+str(item['backdrop_path']),
                    "type":"video", 
                    "plot":str(item['overview'].encode("utf-8")),
                    "year":str(item['release_date'])
                })
        if response['page']<response['total_pages']:
			items.append({
				"title": "Next >",
				"url": "none", 
				"mode":next_mode, 
				"poster":'none',
				"icon":'none', 
				"fanart":'none',
				"type":"video", 
				"plot":'',
				"page":str(int(response['page'])+1),
				"search":search
			})
        addMenuItems(items)

def findPerson(s, type, page=1):
	search=str(s)
	response=tmdb_find(search, type, page)
	if response!=False:
		items=[]
		for item in response['results']:
			title=str(item['name'].encode("utf-8"))
			items.append({
				"title": title,
				"url": str(item['id']), 
				"mode":5, 
				"poster":'https://image.tmdb.org/t/p/w300/'+str(item['profile_path']),
				"icon":'https://image.tmdb.org/t/p/w300/'+str(item['profile_path']), 
				"fanart":'none',
				"type":"video", 
				"plot":'',
			})
		if response['page']<response['total_pages']:
			items.append({
				"title": "Next >",
				"url": "none", 
				"mode":33, 
				"poster":'none',
				"icon":'none', 
				"fanart":'none',
				"type":"video", 
				"plot":'',
				"page":str(int(response['page'])+1),
				"search":search
			})
		addMenuItems(items)

def scrapeWF(params, type):
    response=getHTML('http://www.watchfree.to/?keyword='+urllib.quote_plus(str(params['name']))+'&search_section=1', hdr)
    searchFor=(params['name']+" ("+params['year'][:4]+")").replace(" ", "").lower()
    if response!=False:
        bsObj=BeautifulSoup(response, "html.parser")
        films=bsObj.findAll('div', {'class':'item'})
        if films:
            for item in films:
                target=item.a.attrs['title'][6:].replace(" ", "").lower()
                if re.sub(r'\W+', '', searchFor)==re.sub(r'\W+', '', target):
                    response=getHTML("http://www.watchfree.to/"+item.a.attrs['href'], hdr)
                    if response!=False:
                        bsObj2=BeautifulSoup(response, "html.parser")
                        links=bsObj2.findAll('table', {'class':'link_item'})
                        items=[]
                        quality=re.compile('<div class=["|\']quality["|\']>\[(\S*)\]<\/div>')
                        site=re.compile('<\/strong>[\s-]*([a-zA-Z0-9]*)')
                        target=re.compile('href=[\'|"](\S*)[\'|"]')
                        for link in links:
                            table=str(link)
                            items.append({
                                "title":re.search(site, table).group(1).upper()+" | "+re.search(quality, table).group(1),
                                "url": 'http://www.watchfree.to'+re.search(target, table).group(1), 
                                "mode":9999, 
                                "poster":str(params['poster']),
                                "icon":str(params['icon']), 
                                "fanart":str(params['fanart']),
                                "type":"video", 
                                "plot":'',
                                "realname":params['name']
                            })
                        items=sorted(items)
                        counter=0
                        for link in items:
                            counter=counter+1

                            if len(str(counter))<2:
                                link['title']="0"+str(counter)+' | '+link['title']
                            else:
                                link['title']=str(counter)+' | '+link['title']
                        addMenuItems(items)

def getMediaURL(params):
    user_agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64)'
    headers = { 'User-Agent' : user_agent }
    data = urllib.urlencode('')
    req = urllib2.Request(params['url'], data, headers)
    response = urllib2.urlopen(req)
    link=response.geturl()
    link=urlresolver.resolve(link)
    
    if link:
        try:
            playMedia(params['realname'], params['poster'], link, mediaType='Video')
        except:
            notify(ADDON_ID, "Unable to play stream.")
    else:
        notify(ADDON_ID, "Unable to play stream.")
def playMedia(title, thumbnail, link, mediaType='Video') :
    #link = urlresolver.resolve("https://openload.co/embed/QjfigJGJKs8/")
    """Plays a video

    Arguments:
    title: the title to be displayed
    thumbnail: the thumnail to be used as an icon and thumbnail
    link: the link to the media to be played
    mediaType: the type of media to play, defaults to Video. Known values are Video, Pictures, Music and Programs
    """
    
    try:
        li = xbmcgui.ListItem(label=title, iconImage=thumbnail, thumbnailImage=thumbnail, path=link)
        li.setInfo(type=mediaType, infoLabels={ "Title": title })
        xbmc.Player().play(item=link, listitem=li)
    except:
        if link!=False:
            logError("Unable to play stream. "+str(link))
            notify(ADDON_ID, "Unable to play stream. "+str(link))