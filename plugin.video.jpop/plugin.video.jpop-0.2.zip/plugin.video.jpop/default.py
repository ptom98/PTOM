import audrey
import os, xbmcaddon

home=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path'))

audrey.feedme("https://www.jasonbase.com/things/A2DL.json", "url")
