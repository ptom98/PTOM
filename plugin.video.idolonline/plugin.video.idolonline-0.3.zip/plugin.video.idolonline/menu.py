import sys, urllib, os
import xbmc, xbmcplugin, xbmcgui, xbmcaddon

sysarg=str(sys.argv[1])
ADDON_ID='plugin.video.idolonline'
addon=xbmcaddon.Addon(id=ADDON_ID)
home=xbmc.translatePath(addon.getAddonInfo('path').decode('utf-8'))

# the main menu structure
mainMenu=[
    {
        "title":"Latest Files", 
        "url":"", 
        "mode":1, 
        "poster":"none",
        "icon":os.path.join(home, '', 'icon.png'),
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
        "isPlayable":False,
        "extras":{"page":"1"}
    },
    {
        "title":"Downloaded Files", 
        "url":"", 
        "mode":3, 
        "poster":"none",
        "icon":os.path.join(home, '', 'icon.png'),
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
        "isPlayable":False,
        "extras":{"page":"1"}
    },
    {
        "title":"Search", 
        "url":"", 
        "mode":4, 
        "poster":"none",
        "icon":os.path.join(home, '', 'icon.png'),
        "fanart":os.path.join(home, '', 'fanart.jpg'),
        "type":"", 
        "plot":"",
        "isFolder":True,
        "isPlayable":False,
        "extras":{"page":"1"}
    }
]