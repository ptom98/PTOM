import audrey

audrey.feedme("https://www.jasonbase.com/things/B1W3.json", "url")
