import audrey
import os, xbmcaddon

home=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path'))

audrey.feedme("https://www.jasonbase.com/things/B1W3.json", "url")
