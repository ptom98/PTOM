import audrey
import os, xbmcaddon

home=xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('path'))

audrey.feedme("https://www.jasonbase.com/things/MjA5.json", "url")
